#include "stm32fxx_GPIO_DRIVER.h"

void delay(void)
{
	for (uint32_t i=0; i<5000; i++);
}
int main(void)
{

	GPIO_Handle_t GpioLed;
	GpioLed.pGPIOx = GPIOD;
	GpioLed.GPIO_PinConfig.GPIO_PinNum = GPIO_Pin_Numb_13;
	GpioLed.GPIO_PinConfig.GPIO_PinMode = GPIO_Pin_Mode_1;
	GpioLed.GPIO_PinConfig.GPIO_Speed = GPIO_Pin_Speed_3;
	GpioLed.GPIO_PinConfig.GPIO_Otype= GPIO_Otype_0;
	GpioLed.GPIO_PinConfig.GPIO_PuPd = GPIO_PuPd_1;
	GPIO_PeripheralClk(GPIOD, ENABLE);
	GPIO_Init(&GpioLed);

	while(1)
	{
		GPIO_Toggle(GPIOD, GPIO_Pin_Numb_13 );
		delay();

	}
	return 0;

}
