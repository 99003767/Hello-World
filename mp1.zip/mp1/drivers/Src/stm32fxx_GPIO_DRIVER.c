#include "stm32fxx_GPIO_DRIVER.h"
//creating API prototype
// I.peripheral  clock enable or disable
void GPIO_PeripheralClk(GPIO_RegDef_t *pGPIOx,uint8_t ENorDI)
{
if (ENorDI == ENABLE)
  {
	if (pGPIOx == GPIOA)
	{
		GPIOA_PCLOCK_EN();
	}
	else if (pGPIOx == GPIOB)
		{
			GPIOB_PCLOCK_EN();
		}
	else if (pGPIOx == GPIOC)
			{
				GPIOC_PCLOCK_EN();
			}
	else if (pGPIOx == GPIOD)
			{
				GPIOD_PCLOCK_EN();
			}
	else if (pGPIOx == GPIOE)
			{
				GPIOE_PCLOCK_EN();
			}

	else if (pGPIOx == GPIOH)
			{
				GPIOH_PCLOCK_EN();
			}
  }
else
 {
	if (pGPIOx == GPIOA)
		{
			GPIOA_PCLOCK_DI();
		}
		else if (pGPIOx == GPIOB)
			{
				GPIOB_PCLOCK_DI();
			}
		else if (pGPIOx == GPIOC)
				{
					GPIOC_PCLOCK_DI();
				}
		else if (pGPIOx == GPIOD)
				{
					GPIOD_PCLOCK_DI();
				}
		else if (pGPIOx == GPIOE)
				{
					GPIOE_PCLOCK_DI();
				}

		else if (pGPIOx == GPIOH)
				{
					GPIOH_PCLOCK_DI();
				}

 }
}
// II. Init & DInit
void GPIO_Init(GPIO_Handle_t *pGPIO_Handle_t)
{uint32_t temp;
	//1.Congigure pinmode

	temp = (pGPIO_Handle_t->GPIO_PinConfig.GPIO_PinMode << (2 * pGPIO_Handle_t->GPIO_PinConfig.GPIO_PinNum ) );
				pGPIO_Handle_t->pGPIOx->MODER &= ~( 0x3 << (2 * pGPIO_Handle_t->GPIO_PinConfig.GPIO_PinNum)); //clearing
			pGPIO_Handle_t->pGPIOx->MODER |= temp; //setting
	//2.Config pin OTYPER

	temp = (pGPIO_Handle_t->GPIO_PinConfig.GPIO_Otype << pGPIO_Handle_t ->GPIO_PinConfig.GPIO_PinNum ) ;
	pGPIO_Handle_t ->pGPIOx->OTYPER = ~(0x1 << pGPIO_Handle_t->GPIO_PinConfig.GPIO_PinNum ) ;
	//3. configure the speed

		temp = (pGPIO_Handle_t->GPIO_PinConfig.GPIO_Speed << ( 2 * pGPIO_Handle_t->GPIO_PinConfig.GPIO_PinNum) );
		pGPIO_Handle_t->pGPIOx->OSPEEDR &= ~( 0x3 << ( 2 * pGPIO_Handle_t->GPIO_PinConfig.GPIO_PinNum)); //clearing
		pGPIO_Handle_t->pGPIOx->OSPEEDR |= temp;

		//4. configure the pupd settings
			temp = (pGPIO_Handle_t->GPIO_PinConfig.GPIO_PuPd << ( 2 * pGPIO_Handle_t->GPIO_PinConfig.GPIO_PinNum) );
			pGPIO_Handle_t->pGPIOx->PUPDR &= ~( 0x3 << ( 2 * pGPIO_Handle_t->GPIO_PinConfig.GPIO_PinNum)); //clearing
			pGPIO_Handle_t->pGPIOx->PUPDR |= temp;

		//5.Configuring the alt func
			uint8_t temp1, temp2;

					temp1 = pGPIO_Handle_t->GPIO_PinConfig.GPIO_PinNum / 8;
					temp2 = pGPIO_Handle_t->GPIO_PinConfig.GPIO_PinNum  % 8;
					pGPIO_Handle_t->pGPIOx->AFR[temp1] &= ~(0xF << ( 4 * temp2 ) ); //clearing
					pGPIO_Handle_t->pGPIOx->AFR[temp1] |= (pGPIO_Handle_t->GPIO_PinConfig.GPIO_AltFn << ( 4 * temp2 ) );

}
void GPIO_DInit(GPIO_RegDef_t *pGPIOx);
// III.read/write to/from ports/pin
uint16_t GPIO_ReadfromPort(GPIO_RegDef_t *pGPIOx)
{
	uint16_t temp;
	temp= (uint16_t)(pGPIOx ->IDR);

	return temp;
}
uint8_t GPIO_ReadfromPin(GPIO_RegDef_t *pGPIOx, uint8_t GPIO_PinNum)
{
	uint8_t temp;
	temp= (uint8_t)(pGPIOx->IDR >> GPIO_PinNum & 0x00000001);
	return temp;
}
void GPIO_WritetoPort(GPIO_RegDef_t *pGPIOx, uint16_t value)
{
	pGPIOx -> ODR = value;

}
void GPIO_WritetoPin(GPIO_RegDef_t *pGPIOx, uint8_t GPIO_PinNum, uint16_t value)
{
	if(value == SET)
	{
		pGPIOx ->ODR = 1<<GPIO_PinNum ;
	}
	else
	{
		pGPIOx ->ODR &= ~(1<<GPIO_PinNum);
	}
}
void GPIO_Toggle(GPIO_RegDef_t *pGPIOx, uint8_t GPIO_PinNum )
{
	pGPIOx->ODR ^=(1 << GPIO_PinNum);
}


