#include "Stm32f4xx.h"
// creating the structure for  gpio_pinconfig
typedef struct
{
	uint8_t GPIO_PinNum;//16
	uint8_t GPIO_PinMode;//4
	uint8_t GPIO_Speed;//4
	uint8_t GPIO_Otype; //2 output type
	uint8_t GPIO_PuPd; //3 pull up and pull down
	uint8_t GPIO_AltFn;//16 Alternate function
}GPIO_PinConfig;


//Defining macros for pin number
#define GPIO_Pin_Numb_0  0
#define GPIO_Pin_Numb_1  1
#define GPIO_Pin_Numb_2  2
#define GPIO_Pin_Numb_3  3
#define GPIO_Pin_Numb_4  4
#define GPIO_Pin_Numb_5  5
#define GPIO_Pin_Numb_6  6
#define GPIO_Pin_Numb_7  7
#define GPIO_Pin_Numb_8  8
#define GPIO_Pin_Numb_9  9
#define GPIO_Pin_Numb_10 10
#define GPIO_Pin_Numb_11 11
#define GPIO_Pin_Numb_12 12
#define GPIO_Pin_Numb_13 13
#define GPIO_Pin_Numb_14 14
#define GPIO_Pin_Numb_15 15

//Defining macros for pinmode
#define GPIO_Pin_Mode_1  00
#define GPIO_Pin_Mode_2  01
#define GPIO_Pin_Mode_3  10
#define GPIO_Pin_Mode_4  11

//Defining macros for speed
#define GPIO_Pin_Speed_1  0
#define GPIO_Pin_Speed_2  1
#define GPIO_Pin_Speed_3  2
#define GPIO_Pin_Speed_4  3

//Defining macros for otype
#define GPIO_Otype_0  0
#define GPIO_Otype_1  1

//Defining macros for Pupd
#define GPIO_PuPd_1  1
#define GPIO_PuPd_2  2

//Defining macros for altfn
//#define GPIO_AltFn_1  1
//#define GPIO_AltFn_2  2
//#define GPIO_AltFn_3  3
//#define GPIO_AltFn_4  4
//#define GPIO_AltFn_5  5
//#define GPIO_AltFn_6  6
//#define GPIO_AltFn_7  7
//#define GPIO_AltFn_8  8
//#define GPIO_AltFn_9  9
//#define GPIO_AltFn_10  10
//#define GPIO_AltFn_11  11
//#define GPIO_AltFn_12  12
//#define GPIO_AltFn_13  13
//#define GPIO_AltFn_14  14
//#define GPIO_AltFn_15  15

//Handle structure
typedef struct
{
	GPIO_RegDef_t *pGPIOx; //declared a pointer variable og GPIO RegDef type for selecting port
	GPIO_PinConfig GPIO_PinConfig; //declaring the variable for pin config of the structure type

}GPIO_Handle_t;



//creating API prototype
// I.peripheral  clock enable or disable
void GPIO_PeripheralClk(GPIO_RegDef_t *pGPIOx,uint8_t ENorDI);

// II. Init & DInit
void GPIO_Init(GPIO_Handle_t *pGPIO_Handle_t);
void GPIO_DInit(GPIO_RegDef_t *pGPIOx);
// III.read/write to/from ports/pin
uint16_t GPIO_ReadfromPort(GPIO_RegDef_t *pGPIOx);
uint8_t GPIO_ReadfromPin(GPIO_RegDef_t *pGPIOx, uint8_t GPIO_PinNum);
void GPIO_WritetoPort(GPIO_RegDef_t *pGPIOx, uint16_t value);
void GPIO_WritetoPin(GPIO_RegDef_t *pGPIOx, uint8_t GPIO_PinNum, uint16_t value);
void GPIO_Toggle(GPIO_RegDef_t *pGPIOx, uint8_t GPIO_PinNum );





