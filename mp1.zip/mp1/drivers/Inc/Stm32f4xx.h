//MCU Specific header file
//general macros
#include<stdint.h>
#define __vo volatile
//macros for different memories

#define SRAM1 0x20000000U
#define SRAM2 0x2001C000U
#define Flash 0x08000000U
#define ROM   0x1FFF0000U

//macros for bus system
#define BUS_BASE_ADDR 0x40000000U
#define APB1_BASEADDR 0x40000000U
#define APB2_BASEADDR 0x40010000U
#define AHB1_BASEADDR 0x40020000U
#define AHB2_BASEADDR 0x50000000U

//Macros for rcc

#define RCC_BASE_ADDR (AHB1_BASEADDR + 0x3800)
//#define RCC (RCC_RegDef_t*)RCC_BASE_ADDR

//MACROS TO GPIO
#define GPIOA_BASEADDR (AHB1_BASEADDR + 0x00) //0X40020000
#define GPIOB_BASEADDR (AHB1_BASEADDR + 0x0400)
#define GPIOC_BASEADDR (AHB1_BASEADDR + 0x0800)
#define GPIOD_BASEADDR (AHB1_BASEADDR + 0x0C00)
#define GPIOE_BASEADDR (AHB1_BASEADDR + 0x1000)
#define GPIOF_BASEADDR (AHB1_BASEADDR + 0x1400)
#define GPIOG_BASEADDR (AHB1_BASEADDR + 0x1800)
#define GPIOH_BASEADDR (AHB1_BASEADDR + 0x1C00)
#define GPIOI_BASEADDR (AHB1_BASEADDR + 0x2000)
#define GPIOJ_BASEADDR (AHB1_BASEADDR + 0x2400)
#define GPIOK_BASEADDR (AHB1_BASEADDR + 0x2800)
//MACROS FOR PERIPHARALS HANGING ONTO APB BUS
//MACROSfor timers
#define TIMER1_BASEADDR (APB2_BASEADDR + 0X0000)
#define TIMER2_BASEADDR (APB1_BASEADDR + 0X0000)
#define TIMER3_BASEADDR (APB1_BASEADDR + 0X0400)
#define TIMER4_BASEADDR (APB1_BASEADDR + 0X0800)
#define TIMER5_BASEADDR (APB1_BASEADDR + 0X0C00)
#define TIMER6_BASEADDR (APB1_BASEADDR + 0X1000)
#define TIMER7_BASEADDR (APB1_BASEADDR + 0X1400)
#define TIMER12_BASEADDR (APB1_BASEADDR + 0X1800)
#define TIMER13_BASEADDR (APB1_BASEADDR + 0X1C00)
#define TIMER14_BASEADDR (APB1_BASEADDR + 0X2000)

#define TIMER8_BASEADDR (APB2_BASEADDR + 0X0400)
#define TIMER9_BASEADDR (APB2_BASEADDR + 0X4000)
#define TIMER10_BASEADDR (APB2_BASEADDR + 0X4400)
#define TIMER11_BASEADDR (APB2_BASEADDR + 0X4800)

//GPIO REGISTER DEFINITIONS
typedef struct
{
	__vo uint32_t MODER;//+00 offset
	__vo uint32_t OTYPER;//+04 offset
volatile uint32_t OSPEEDR;//+08 offset
volatile uint32_t PUPDR;//+0C offset
volatile uint32_t IDR;//+10 offset
volatile uint32_t ODR;//+14 offset
volatile uint32_t BSRR;//+18 offset
volatile uint32_t LCKR;//+1C offset
volatile uint32_t AFR[2];//+20 offset


}GPIO_RegDef_t;

typedef struct{
volatile uint32_t RCC_CR; //0x00
volatile uint32_t RCC_PLLCFGR; //0x04
volatile uint32_t RCC_CFGR;//0x08
volatile uint32_t RCC_CIR;//0x0c
volatile uint32_t RCC_AHB1RSTR;//0x10
volatile uint32_t RCC_AHB2RSTR;//0x14
volatile uint32_t RCC_AHB3RSTR;//0x18
uint32_t      RESERVED0;
volatile uint32_t RCC_APB1RSTR;//0x20
volatile uint32_t RCC_APB2RSTR;//0x24
uint32_t      RESERVED1[2];
volatile uint32_t RCC_AHB1ENR;//0x30
volatile uint32_t RCC_AHB2ENR;//0x34
volatile uint32_t RCC_AHB3ENR;//0x38
uint32_t      RESERVED2;
volatile uint32_t RCC_APB1ENR;//040
volatile uint32_t RCC_APB2ENR;//0x44
uint32_t      RESERVED3[2];
volatile uint32_t RCC_AHB1LPENR;//0x50
volatile uint32_t RCC_AHB2LPENR;//0x54
volatile uint32_t RCC_AHB3LPENR;//0x58
uint32_t      RESERVED4;
volatile uint32_t RCC_APB1LPENR;//0x60
volatile uint32_t RCC_APB2LPENR;//0x64
uint32_t      RESERVED5[2];
volatile uint32_t RCC_BDCR;//0x70
volatile uint32_t RCC_CSR;//0x74
uint32_t      RESERVED6[2];
volatile uint32_t RCC_SSCGR;//0x80
volatile uint32_t RCC_PLLI2SCFGR;//0x84
volatile uint32_t RCC_PLLSAICFGR;//0x88
volatile uint32_t RCC_DCKCFGR;//0x8C
}RCC_RegDef_t;


//Macros for gpio pointer structure
#define GPIOA ((GPIO_RegDef_t*)GPIOA_BASEADDR)
#define GPIOB ((GPIO_RegDef_t*)GPIOB_BASEADDR)
#define GPIOC ((GPIO_RegDef_t*)GPIOC_BASEADDR)
#define GPIOD ((GPIO_RegDef_t*)GPIOD_BASEADDR)
#define GPIOE ((GPIO_RegDef_t*)GPIOE_BASEADDR)
#define GPIOF ((GPIO_RegDef_t*)GPIOF_BASEADDR)
#define GPIOG ((GPIO_RegDef_t*)GPIOG_BASEADDR)
#define GPIOH ((GPIO_RegDef_t*)GPIOH_BASEADDR)
#define GPIOI ((GPIO_RegDef_t*)GPIOI_BASEADDR)

#define RCC ((RCC_RegDef_t*)RCC_BASE_ADDR)
//todo

//Macros for enabling the clock for gpio's

#define GPIOA_PCLOCK_EN() (RCC->RCC_AHB1ENR |= (1<<0))
#define GPIOB_PCLOCK_EN() (RCC->RCC_AHB1ENR |= (1<<1))
#define GPIOC_PCLOCK_EN() (RCC->RCC_AHB1ENR |= (1<<2))
#define GPIOD_PCLOCK_EN() (RCC->RCC_AHB1ENR |= (1<<3))
#define GPIOE_PCLOCK_EN() (RCC->RCC_AHB1ENR |= (1<<4))
#define GPIOE_PCLOCK_EN() (RCC->RCC_AHB1ENR |= (1<<5))
#define GPIOE_PCLOCK_EN() (RCC->RCC_AHB1ENR |= (1<<6))
#define GPIOH_PCLOCK_EN() (RCC->RCC_AHB1ENR |= (1<<7))
#define GPIOH_PCLOCK_EN() (RCC->RCC_AHB1ENR |= (1<<8))


/* GPIO Peripheral Clock Disable Macros */
#define GPIOA_PCLOCK_DI() (RCC->RCC_AHB1RSTR&=~(1<<0))
#define GPIOB_PCLOCK_DI() (RCC->RCC_AHB1RSTR&=~(1<<1))
#define GPIOC_PCLOCK_DI() (RCC->RCC_AHB1RSTR&=~(1<<2))
#define GPIOD_PCLOCK_DI() (RCC->RCC_AHB1RSTR&=~(1<<3))
#define GPIOE_PCLOCK_DI() (RCC->RCC_AHB1RSTR&=~(1<<4))
#define GPIOA_PCLOCK_DI() (RCC->RCC_AHB1RSTR&=~(1<<5))
#define GPIOA_PCLOCK_DI() (RCC->RCC_AHB1RSTR&=~(1<<6))
#define GPIOH_PCLOCK_DI() (RCC->RCC_AHB1RSTR&=~(1<<7))
#define GPIOA_PCLOCK_DI() (RCC->RCC_AHB1RSTR&=~(1<<8))


/*Other Macro Definitions */
#define ENABLE  1
#define DISABLE  0
#define SET 1
#define RESET 0
#define GPIO_Pin_Set ENABLE
#define GPIO_Pin_Reset DISABLE
